var button = document.querySelector(".name-of-form");
var form = document.querySelector(".form-index-show");

form.classList.remove("form-index");

button.addEventListener("click", function(){
  form.classList.toggle("form-index");
});
